<h1>Security</h1>
<p>
    <center>Please remove <b>ow_install/</b> folder and refresh this page.</center>
</p>