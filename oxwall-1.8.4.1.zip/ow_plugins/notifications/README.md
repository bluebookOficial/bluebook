# notifications
Activity notifications plugin for Oxwall. Real-time and email notifications about site activity.
